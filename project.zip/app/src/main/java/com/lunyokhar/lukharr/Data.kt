package com.lunyokhar.lukharr

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Song(val id: Long, val title: String, val artist: String, val albumId: Long)

fun Song.artUri(): Uri = Uri.parse("content://media/external/audio/albumart/$albumId")

fun Song.toItem(): MediaItem = MediaItem.Builder()
    .setMediaId(id.toString())
    .setUri(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id))
    .setMediaMetadata(
        MediaMetadata.Builder().setTitle(title).setArtist(artist).setArtworkUri(artUri()).build()
    ).build()

fun loadSongs(ctx: Context): List<Song> {
    val out = ArrayList<Song>()
    val m = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM_ID
    )
    ctx.contentResolver.query(
        m, proj, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
        "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
    )?.use { c ->
        while (c.moveToNext()) {
            val artist = c.getString(2).let { if (it.isNullOrBlank() || it == "<unknown>") "Unknown" else it }
            out.add(Song(c.getLong(0), c.getString(1) ?: "Unknown", artist, c.getLong(3)))
        }
    }
    return out
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("lukharr", Context.MODE_PRIVATE)
    fun dark(c: Context) = sp(c).getBoolean("dark", true)
    fun setDark(c: Context, v: Boolean) = sp(c).edit().putBoolean("dark", v).apply()
    fun my(c: Context) = sp(c).getBoolean("my", true)
    fun setMy(c: Context, v: Boolean) = sp(c).edit().putBoolean("my", v).apply()
    fun lastId(c: Context) = sp(c).getLong("lastId", -1L)
    fun lastPos(c: Context) = sp(c).getLong("lastPos", 0L)
    fun setLast(c: Context, id: Long, pos: Long) =
        sp(c).edit().putLong("lastId", id).putLong("lastPos", pos).apply()
    fun recent(c: Context): List<Long> =
        (sp(c).getString("recent", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }
    fun addRecent(c: Context, id: Long) {
        val l = (listOf(id) + recent(c).filter { it != id }).take(30)
        sp(c).edit().putString("recent", l.joinToString(",")).apply()
    }
}

class Str(private val my: Boolean) {
    private fun s(en: String, mm: String) = if (my) mm else en
    val songs = s("Songs", "သီချင်းများ")
    val recent = s("Recent", "မကြာသေးမီက")
    val settings = s("Settings", "ဆက်တင်")
    val search = s("Search songs", "သီချင်းရှာရန်")
    val theme = s("Theme", "အသွင်အပြင်")
    val light = s("Light", "အလင်း")
    val dark = s("Dark", "အမှောင်")
    val language = s("Language", "ဘာသာစကား")
    val creator = s("Creator", "ဖန်တီးသူ")
    val noSongs = s("No songs found on this phone", "ဖုန်းထဲတွင် သီချင်း မတွေ့ပါ")
    val noRecent = s("Nothing played yet", "မဖွင့်ရသေးပါ")
    val allow = s("Allow access to your music files", "သီချင်းဖိုင်များ ဖတ်ခွင့်ပေးပါ")
    val allowBtn = s("Allow", "ခွင့်ပြုမည်")
}
