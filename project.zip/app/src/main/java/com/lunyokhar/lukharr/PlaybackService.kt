package com.lunyokhar.lukharr

import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private val handler = Handler(Looper.getMainLooper())
    private val saver = object : Runnable {
        override fun run() { save(); handler.postDelayed(this, 3000) }
    }

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA).build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(saver)
                if (isPlaying) { recordRecent(); handler.post(saver) } else save()
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (player.playWhenReady) recordRecent()
            }
        })
        session = MediaSession.Builder(this, player).build()
    }

    private fun recordRecent() {
        player.currentMediaItem?.mediaId?.toLongOrNull()?.let { Prefs.addRecent(this, it) }
    }

    private fun save() {
        player.currentMediaItem?.mediaId?.toLongOrNull()
            ?.let { Prefs.setLast(this, it, player.currentPosition) }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(saver)
        save()
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }
}
