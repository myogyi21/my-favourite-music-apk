@file:OptIn(ExperimentalMaterial3Api::class)

package com.lunyokhar.lukharr

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImagePainter
import coil.compose.SubcomposeAsyncImage
import coil.compose.SubcomposeAsyncImageContent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

val DarkC = darkColorScheme(
    primary = Color(0xFFB388FF), onPrimary = Color(0xFF1A0B33), secondary = Color(0xFFFF6FB5),
    background = Color(0xFF0F0B1E), surface = Color(0xFF1B1530), surfaceVariant = Color(0xFF2A2145),
    onBackground = Color(0xFFF1EAFF), onSurface = Color(0xFFF1EAFF), onSurfaceVariant = Color(0xFFB9AEDA)
)
val LightC = lightColorScheme(
    primary = Color(0xFF7C4DFF), onPrimary = Color.White, secondary = Color(0xFFE91E8C),
    background = Color(0xFFF8F4FF), surface = Color.White, surfaceVariant = Color(0xFFEDE5FF),
    onBackground = Color(0xFF1E1633), onSurface = Color(0xFF1E1633), onSurfaceVariant = Color(0xFF5D5280)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var dark by remember { mutableStateOf(Prefs.dark(ctx)) }
    var my by remember { mutableStateOf(Prefs.my(ctx)) }
    val t = remember(my) { Str(my) }
    MaterialTheme(colorScheme = if (dark) DarkC else LightC) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Main(t, dark, my, { dark = it; Prefs.setDark(ctx, it) }, { my = it; Prefs.setMy(ctx, it) })
        }
    }
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun Art(model: Any?, modifier: Modifier) {
    val ph = Brush.linearGradient(listOf(Color(0xFF7C4DFF), Color(0xFFFF6FB5)))
    SubcomposeAsyncImage(model = model, contentDescription = null, contentScale = ContentScale.Crop, modifier = modifier) {
        if (painter.state is AsyncImagePainter.State.Success) SubcomposeAsyncImageContent()
        else Box(Modifier.fillMaxSize().background(ph), contentAlignment = Alignment.Center) {
            Text("♪", color = Color.White, fontSize = 22.sp)
        }
    }
}

@Composable
fun Main(t: Str, dark: Boolean, my: Boolean, onDark: (Boolean) -> Unit, onMy: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val audioPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE
    val perms = if (Build.VERSION.SDK_INT >= 33) arrayOf(audioPerm, Manifest.permission.POST_NOTIFICATIONS)
    else arrayOf(audioPerm)
    fun has() = ContextCompat.checkSelfPermission(ctx, audioPerm) == PackageManager.PERMISSION_GRANTED
    var granted by remember { mutableStateOf(has()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = has() }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(perms) }

    var songs by remember { mutableStateOf(emptyList<Song>()) }
    LaunchedEffect(granted) { if (granted) songs = withContext(Dispatchers.IO) { loadSongs(ctx) } }

    var controller by remember { mutableStateOf<MediaController?>(null) }
    DisposableEffect(Unit) {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val f = MediaController.Builder(ctx, token).buildAsync()
        f.addListener({ try { controller = f.get() } catch (e: Exception) { } }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(f); controller = null }
    }

    var curItem by remember { mutableStateOf<MediaItem?>(null) }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    DisposableEffect(controller) {
        val c = controller
        if (c == null) {
            onDispose { }
        } else {
            curItem = c.currentMediaItem; playing = c.isPlaying
            val l = object : Player.Listener {
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { curItem = c.currentMediaItem }
                override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            }
            c.addListener(l)
            onDispose { c.removeListener(l) }
        }
    }
    LaunchedEffect(controller, playing, curItem) {
        val c = controller ?: return@LaunchedEffect
        pos = c.currentPosition; dur = c.duration.coerceAtLeast(0)
        while (playing) {
            delay(500)
            pos = c.currentPosition; dur = c.duration.coerceAtLeast(0)
        }
    }

    // Resume the last song (paused) when the app is opened again
    LaunchedEffect(controller, songs) {
        val c = controller ?: return@LaunchedEffect
        if (songs.isEmpty() || c.mediaItemCount != 0) return@LaunchedEffect
        val lastId = Prefs.lastId(ctx)
        val idx = songs.indexOfFirst { it.id == lastId }
        c.setMediaItems(songs.map { it.toItem() }, if (idx < 0) 0 else idx, if (idx < 0) 0L else Prefs.lastPos(ctx))
        c.prepare()
    }

    var recentIds by remember { mutableStateOf(Prefs.recent(ctx)) }
    LaunchedEffect(curItem, playing) { delay(300); recentIds = Prefs.recent(ctx) }
    val byId = remember(songs) { songs.associateBy { it.id } }
    val recentSongs = recentIds.mapNotNull { byId[it] }

    fun playSong(s: Song) {
        val c = controller ?: return
        val i = songs.indexOfFirst { it.id == s.id }
        if (i < 0) return
        if (c.mediaItemCount != songs.size) c.setMediaItems(songs.map { it.toItem() })
        c.seekTo(i, 0L); c.prepare(); c.play()
    }

    var tab by remember { mutableIntStateOf(0) }
    var full by remember { mutableStateOf(false) }
    val curId = curItem?.mediaId?.toLongOrNull()

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                Column {
                    val c = controller
                    if (curItem != null && c != null) Mini(curItem!!, playing, c) { full = true }
                    NavigationBar {
                        NavigationBarItem(tab == 0, { tab = 0 }, { Text("♫", fontSize = 20.sp) }, label = { Text(t.songs) })
                        NavigationBarItem(tab == 1, { tab = 1 }, { Text("◷", fontSize = 20.sp) }, label = { Text(t.recent) })
                        NavigationBarItem(tab == 2, { tab = 2 }, { Text("⚙", fontSize = 20.sp) }, label = { Text(t.settings) })
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> SongsTab(t, songs, granted, curId, { launcher.launch(perms) }) { playSong(it) }
                    1 -> RecentTab(t, recentSongs, curId) { playSong(it) }
                    else -> SettingsTab(t, dark, my, onDark, onMy)
                }
            }
        }
        val c = controller
        if (full && curItem != null && c != null) {
            BackHandler { full = false }
            FullPlayer(curItem!!, playing, pos, dur, c) { full = false }
        }
    }
}

@Composable
fun SongRow(s: Song, current: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(s.artUri(), Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold,
                color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
            Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (current) Text("♪", color = MaterialTheme.colorScheme.secondary, fontSize = 20.sp)
    }
}

@Composable
fun SongsTab(t: Str, songs: List<Song>, granted: Boolean, curId: Long?, onGrant: () -> Unit, onPlay: (Song) -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = remember(songs, q) {
        if (q.isBlank()) songs else songs.filter { it.title.contains(q, true) || it.artist.contains(q, true) }
    }
    Column(Modifier.fillMaxSize()) {
        Text("LUKHARR", Modifier.padding(start = 20.dp, top = 16.dp), fontSize = 26.sp,
            fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
        OutlinedTextField(
            q, { q = it }, Modifier.fillMaxWidth().padding(16.dp), singleLine = true,
            placeholder = { Text(t.search) }, shape = RoundedCornerShape(24.dp)
        )
        if (!granted) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(t.allow, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onGrant) { Text(t.allowBtn) }
            }
        } else if (songs.isEmpty()) {
            Text(t.noSongs, Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.id }) { s -> SongRow(s, s.id == curId) { onPlay(s) } }
            }
        }
    }
}

@Composable
fun RecentTab(t: Str, list: List<Song>, curId: Long?, onPlay: (Song) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text(t.recent, Modifier.padding(20.dp), fontSize = 24.sp, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary)
        if (list.isEmpty()) Text(t.noRecent, Modifier.padding(horizontal = 20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(Modifier.fillMaxSize()) {
            items(list, key = { it.id }) { s -> SongRow(s, s.id == curId) { onPlay(s) } }
        }
    }
}

@Composable
fun SettingsTab(t: Str, dark: Boolean, my: Boolean, onDark: (Boolean) -> Unit, onMy: (Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(t.settings, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(24.dp))
        Text(t.theme, fontWeight = FontWeight.SemiBold)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(!dark, { onDark(false) }, { Text(t.light) })
            FilterChip(dark, { onDark(true) }, { Text(t.dark) })
        }
        Spacer(Modifier.height(24.dp))
        Text(t.language, fontWeight = FontWeight.SemiBold)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(my, { onMy(true) }, { Text("မြန်မာ") })
            FilterChip(!my, { onMy(false) }, { Text("English") })
        }
        Spacer(Modifier.height(32.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("LUKHARR", fontWeight = FontWeight.Black, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                Text("Offline Music Player", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                Text("${t.creator}: Lunyokhar", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun Mini(item: MediaItem, playing: Boolean, c: MediaController, onOpen: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable { onOpen() }.padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(item.mediaMetadata.artworkUri, Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.mediaMetadata.title?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(item.mediaMetadata.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        IconButton({ c.seekToPreviousMediaItem() }) { Text("⏮", fontSize = 20.sp) }
        IconButton({ if (c.isPlaying) c.pause() else c.play() }) { Text(if (playing) "⏸" else "▶", fontSize = 22.sp) }
        IconButton({ c.seekToNextMediaItem() }) { Text("⏭", fontSize = 20.sp) }
    }
}

@Composable
fun FullPlayer(item: MediaItem, playing: Boolean, pos: Long, dur: Long, c: MediaController, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(cs.primary.copy(alpha = 0.35f), cs.background)))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth()) { TextButton(onClose) { Text("⌄", fontSize = 28.sp) } }
        Spacer(Modifier.height(8.dp))
        Art(item.mediaMetadata.artworkUri, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(28.dp)))
        Spacer(Modifier.height(28.dp))
        Text(item.mediaMetadata.title?.toString() ?: "", fontSize = 22.sp, fontWeight = FontWeight.Bold,
            maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        Text(item.mediaMetadata.artist?.toString() ?: "", color = cs.onSurfaceVariant, maxLines = 1)
        Spacer(Modifier.height(20.dp))
        Slider(
            value = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f,
            onValueChange = { if (dur > 0) c.seekTo((it * dur).toLong()) }
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(pos), fontSize = 12.sp, color = cs.onSurfaceVariant)
            Text(fmt(dur), fontSize = 12.sp, color = cs.onSurfaceVariant)
        }
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            IconButton({ c.seekToPreviousMediaItem() }, Modifier.size(56.dp)) { Text("⏮", fontSize = 30.sp) }
            Box(
                Modifier.size(76.dp).clip(CircleShape).background(cs.primary)
                    .clickable { if (c.isPlaying) c.pause() else c.play() },
                contentAlignment = Alignment.Center
            ) { Text(if (playing) "⏸" else "▶", fontSize = 32.sp, color = cs.onPrimary) }
            IconButton({ c.seekToNextMediaItem() }, Modifier.size(56.dp)) { Text("⏭", fontSize = 30.sp) }
        }
    }
}
